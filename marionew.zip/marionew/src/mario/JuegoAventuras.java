package mario;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import mario.Game_Over;
import mario.You_Won;

class MovingObstacle extends Rectangle {
    float velocity;
    float min, max;
    boolean isHorizontal;

    MovingObstacle(int x, int y, int width, int height, float min, float max, float velocity, boolean isHorizontal) {
        super(x, y, width, height);
        this.min = min;
        this.max = max;
        this.velocity = velocity;
        this.isHorizontal = isHorizontal;
    }

    void update() {
        if (isHorizontal) {
            x += velocity;
            if (x <= min || x >= max) {
                velocity = -velocity;
            }
        } else {
            y += velocity;
            if (y <= min || y >= max) {
                velocity = -velocity;
            }
        }
    }
}

class ZigzagObstacle extends Rectangle {
    float velocity;
    float min, max;
    boolean movingUp;

    ZigzagObstacle(int x, int y, int width, int height, float min, float max, float velocity, boolean movingUp) {
        super(x, y, width, height);
        this.min = min;
        this.max = max;
        this.velocity = velocity;
        this.movingUp = movingUp;
    }

    void update() {
        if (movingUp) {
            y -= velocity;
            if (y <= min) {
                movingUp = false;
            }
        } else {
            y += velocity;
            if (y >= max) {
                movingUp = true;
            }
        }
    }
}

class BombaCayendo extends Rectangle {
    float velocidad;
    boolean explotando;
    int duracionExplosion;
    ImageIcon gifExplosion;
    private static final int DURACION_EXPLOSION_MAX = 10;
    int explosionSize = 50; // Reduce el tamaño de la explosión

    BombaCayendo(int x, int y, int ancho, int alto, float velocidad) {
        super(x, y, ancho, alto);
        this.velocidad = velocidad;
        this.explotando = false;
        this.duracionExplosion = 0;
        this.gifExplosion = new ImageIcon("C:\\Users\\Sergio\\Downloads\\mario\\src\\mario\\explosion.gif");
    }

    void actualizar() {
        if (!explotando) {
            y += velocidad;
            velocidad += 0.2f;

            if (y >= 600 - 230 - height) {
                y = 600 - 230 - height;
                velocidad = 0;
                explotando = true;
                duracionExplosion = 0;
            }
        } else {
            duracionExplosion++;
            if (duracionExplosion > DURACION_EXPLOSION_MAX) {
                y = 600;
                velocidad = 0;
            }
        }
    }

    boolean debeDesaparecer() {
        return duracionExplosion > DURACION_EXPLOSION_MAX;
    }

    // Agrega un método para comprobar si el jugador está dentro del rango de la explosión
    boolean estaDentroDelRango(Rectangle jugador) {
        return jugador.intersects(new Rectangle(x - explosionSize / 2, y - explosionSize / 2, explosionSize, explosionSize));
    }
}

class Bullet extends Rectangle {
    float velocityX;
    boolean isPlayerBullet;

    Bullet(int x, int y, int width, int height, float velocityX, boolean isPlayerBullet) {
        super(x, y, width, height);
        this.velocityX = velocityX;
        this.isPlayerBullet = isPlayerBullet;
    }

    void update() {
        x += velocityX;
    }
}

class Bowser extends Rectangle {
    int lives;
    int shootTimer;
    boolean facingLeft;
    boolean isAttacking;

    Bowser(int x, int y, int width, int height) {
        super(x, y, width, height);
        lives = 20;
        shootTimer = 0;
        facingLeft = true;
        isAttacking = false;
    }

    void update() {
        shootTimer++;
        if (shootTimer >= 100) {
            isAttacking = true;
        }
    }

    boolean canShoot() {
        return shootTimer >= 100;
    }

    void resetShootTimer() {
        shootTimer = 0;
        isAttacking = false;
    }
}

public class JuegoAventuras extends JPanel implements ActionListener, KeyListener {
    static final int WIDTH = 1280;
    private static final int HEIGHT = 600;
    private static final int FLOOR_HEIGHT = 230;
    private static final int PLAYER_SIZE = 60;
    private static final int OBSTACLE_SIZE = 30;
    private static final int GOAL_SIZE = 120;
    private static final float GRAVITY = 1f;
    private static final float JUMP_STRENGTH = 16f;
    private static final float MAX_SPEED_X = 7f;
    private static final float ACCELERATION_X = 1f;
    private static final float DECELERATION_X = 1f;
    static final int MAP_WIDTH = 1600;
    private static final int BOWSER_WIDTH = 200;
    private static final int BOWSER_HEIGHT = 200;
    private ImageIcon playerBulletImage;
    private ImageIcon bowserBulletGif;
    
    private Timer timer;
    private float playerX = 0;
    private float playerY = HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE;
    private float playerSpeedX = 0;
    private float velocityY = 0;
    private boolean jumping = false;
    private int level = 1;

    private List<Rectangle> obstacles;
    private Rectangle goal;
    private boolean movingLeft = false;
    private boolean movingRight = false;
    private int lives = 3;
    private boolean gameWon = false;
    private boolean gameOver = false;

    private BufferedImage backgroundImage;
    private BufferedImage obstacleImage;
    private BufferedImage obstacleImage2;
    private BufferedImage heartImage;
    private BufferedImage playerImageStand;
    private BufferedImage playerImageLeft;
    private BufferedImage playerImageRight;
    private BufferedImage playerImageJump;
    private BufferedImage bandera;
    private BufferedImage bomba;
    private BufferedImage fuego;
    private BufferedImage explosion;
    private List<BombaCayendo> bombas;
    
    private boolean inKnockback = false;
    private int knockbackDuration = 0;
    private static final int MAX_KNOCKBACK_DURATION = 20;

    private boolean inMenu = true;
    private int menuSelection = 0;
    private BufferedImage menuBackgroundImage;
    private Font pixelFont;

    private Bowser bowser;
    private List<Bullet> bullets;
    private boolean shooting = false;
    private int shootCooldown = 0;

    private ImageIcon bowserBreathingGif;
    private ImageIcon bowserAttackingGif;
    private ImageIcon bulletImage;

    public JuegoAventuras() {
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);

        obstacles = new ArrayList<>();
        bullets = new ArrayList<>();
        initializeLevel(level);

        loadImages();
        loadFont();

        timer = new Timer(20, this);
        timer.start();
    }

    private void loadImages() {
        try {
            backgroundImage = ImageIO.read(new File("E:\\marionew\\src\\mario\\fondo.png"));
            obstacleImage = ImageIO.read(new File("E:\\marionew\\src\\mario\\Bola_pincho.png"));
            obstacleImage2 = ImageIO.read(new File("E:\\marionew\\src\\mario\\bola-level2.png"));
            heartImage = ImageIO.read(new File("E:\\marionew\\\\src\\mario\\corazon.png"));
            playerImageStand = ImageIO.read(new File("E:\\marionew\\src\\mario\\personaje.png"));
            playerImageLeft = ImageIO.read(new File("E:\\marionew\\src\\mario\\izquierda.png"));
            playerImageRight = ImageIO.read(new File("E:\\marionew\\src\\mario\\derecha.png"));
            playerImageJump = ImageIO.read(new File("E:\\marionew\\src\\mario\\saltar.png"));
            menuBackgroundImage = ImageIO.read(new File("E:\\marionew\\src\\mario\\final.png"));
            bandera = ImageIO.read(new File("E:\\marionew\\src\\mario\\bandera-final.png"));
            bomba = ImageIO.read(new File("E:\\marionew\\src\\mario\\bomba.png"));
            
            bowserBreathingGif = new ImageIcon("E:\\marionew\\src\\mario\\bowser_respirar.gif");
            bowserAttackingGif = new ImageIcon("E:\\marionew\\src\\mario\\bowser_ataque.gif");
            playerBulletImage = new ImageIcon("E:\\marionew\\src\\mario\\bomba.png");
            bowserBulletGif = new ImageIcon("E:\\marionew\\src\\mario\\fuego.gif");
        
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error al cargar las imágenes.");
        }
    }

    private void loadFont() {
        try {
            InputStream is = getClass().getResourceAsStream("Fuente_retro.ttf");
            pixelFont = Font.createFont(Font.TRUETYPE_FONT, is).deriveFont(25f);
        } catch (Exception e) {
            e.printStackTrace();
            pixelFont = new Font("Arial", Font.PLAIN, 40);
        }
    }

    private void initializeLevel(int level) {
        obstacles.clear();
        bombas = new ArrayList<>();
        bullets.clear();
        
        switch (level) {
            case 1:
                for (int i = 0; i < 6; i++) {
                    obstacles.add(new Rectangle(400 + i * 200, HEIGHT - FLOOR_HEIGHT - 50, 60, 50));
                }
                break;
            case 2:
                lives++;
                int startX = 300;
                int obstacleHeight = OBSTACLE_SIZE;
                int groundY = HEIGHT - FLOOR_HEIGHT - OBSTACLE_SIZE - 55;
                int range = 50;

                for (int i = 0; i < 10; i++) {
                    obstacles.add(new MovingObstacle(
                        startX + i * (OBSTACLE_SIZE + 120),
                        groundY - obstacleHeight,
                        OBSTACLE_SIZE,
                        OBSTACLE_SIZE,
                        groundY - range,
                        groundY + range,
                        2,
                        false
                    ));
                }
                break;
            case 3:
            	lives=lives+6;
                for (int i = 0; i < 5; i++) {
                    bombas.add(new BombaCayendo(
                        (int) (Math.random() * (MAP_WIDTH - 30)),
                        0,
                        40,
                        30,
                        2f
                    ));
                }
                break;
            case 4:
                lives++;
                startX = 300;
                obstacleHeight = OBSTACLE_SIZE;
                groundY = HEIGHT - FLOOR_HEIGHT - OBSTACLE_SIZE - 55;
                range = 50;

                for (int i = 0; i < 10; i++) {
                    boolean movingUp = (i % 2 == 0);
                    obstacles.add(new ZigzagObstacle(
                        startX + i * (OBSTACLE_SIZE + 150),
                        groundY - obstacleHeight,
                        OBSTACLE_SIZE,
                        OBSTACLE_SIZE,
                        groundY - range,
                        groundY + range,
                        2f,
                        movingUp
                    ));
                }
                break;
            case 5:
                
                if (level == 5) {
                    int bowserY = HEIGHT - FLOOR_HEIGHT - BOWSER_HEIGHT;
                    bowser = new Bowser(MAP_WIDTH - 500, bowserY-160, BOWSER_WIDTH, BOWSER_HEIGHT);
                }
                break;
        }

        if (level != 5) {
            goal = new Rectangle(MAP_WIDTH - GOAL_SIZE, HEIGHT - FLOOR_HEIGHT - GOAL_SIZE, GOAL_SIZE, GOAL_SIZE);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (inMenu) {
            paintMenu(g);
        } else {
            paintGame(g);
        }
    }
    
    private void paintMenu(Graphics g) {
        if (menuBackgroundImage != null) {
            g.drawImage(menuBackgroundImage, 0, 0, getWidth(), getHeight(), this);
        }

        g.setFont(pixelFont);
        FontMetrics metrics = g.getFontMetrics(pixelFont);

        String iniciarTexto = "Iniciar Juego";
        String salirTexto = "Salir";

        int iniciarX = (getWidth() - metrics.stringWidth(iniciarTexto)) / 2;
        int salirX = (getWidth() - metrics.stringWidth(salirTexto)) / 2;

        g.setColor(menuSelection == 0 ? new Color(0xff5721) : Color.WHITE);
        g.drawString(iniciarTexto, iniciarX, 400);

        g.setColor(menuSelection == 1 ? new Color(0xff5721) : Color.WHITE);
        g.drawString(salirTexto, salirX, 500);
    }

    private void paintGame(Graphics g) {
        int mapOffsetX = Math.max(0, Math.min((int) (playerX - WIDTH / 2), MAP_WIDTH - WIDTH));

        if (backgroundImage != null) {
            g.drawImage(backgroundImage, -mapOffsetX, 0, MAP_WIDTH, HEIGHT, this);
        } else {
            g.setColor(Color.cyan);
            g.fillRect(0, 0, WIDTH, HEIGHT);
        }

        BufferedImage currentPlayerImage;
        if (jumping) {
            currentPlayerImage = playerImageJump;
        } else if (movingLeft) {
            currentPlayerImage = playerImageLeft;
        } else if (movingRight) {
            currentPlayerImage = playerImageRight;
        } else {
            currentPlayerImage = playerImageStand;
        }

        if (currentPlayerImage != null) {
            g.drawImage(currentPlayerImage, (int) (playerX - mapOffsetX), (int) playerY, PLAYER_SIZE, PLAYER_SIZE, this);
        }

        BufferedImage currentObstacleImage = (level == 2 || level == 4) ? obstacleImage2 : obstacleImage;

        if (currentObstacleImage != null) {
            for (Rectangle obs : obstacles) {
                g.drawImage(currentObstacleImage, (int) (obs.x - mapOffsetX), (int) obs.y, obs.width, obs.height, this);
            }
        }

        if (level != 5 && bandera != null) {
            g.drawImage(bandera, (int) (goal.x - mapOffsetX), (int) goal.y, GOAL_SIZE - 30, GOAL_SIZE, this);
        }

        if (heartImage != null) {
            int heartSize = 40;
            for (int i = 0; i < lives; i++) {
                g.drawImage(heartImage, WIDTH - (i + 1) * (heartSize + 5), 10, heartSize, heartSize, this);
            }
        }

        if (bomba != null) {
            for (BombaCayendo bomba : bombas) {
                if (bomba.explotando) {
                    int explosionX = (int) (bomba.x - mapOffsetX - (bomba.explosionSize - bomba.width) / 2);
                    int explosionY = (int) (bomba.y - (bomba.explosionSize - bomba.height) / 2);
                    bomba.gifExplosion.paintIcon(this, g, explosionX, explosionY);
                } else {
                    g.drawImage(this.bomba, (int) (bomba.x - mapOffsetX), (int) bomba.y, bomba.width, bomba.height, this);
                }
            }
        }

        if (level == 5) {
            // Dibujar Bowser
        	  ImageIcon currentBowserGif = bowser.isAttacking ? bowserAttackingGif : bowserBreathingGif;
              if (currentBowserGif != null) {
                  currentBowserGif.paintIcon(this, g, (int) (bowser.x - mapOffsetX), (int) bowser.y);
              }
            

            // Dibujar balas
              for (Bullet bullet : bullets) {
            	    Image bulletImage;
            	    int bulletWidth, bulletHeight;

            	    if (bullet.isPlayerBullet) {
            	        // Configuración para las balas del jugador
            	        bulletImage = playerBulletImage.getImage();  // Imagen de la bala del jugador
            	        bulletWidth = bullet.width;  // Tamaño de la bala del jugador (por ejemplo, 5)
            	        bulletHeight = bullet.height; // Tamaño de la bala del jugador (por ejemplo, 5)
            	    } else {
            	        // Configuración para las balas de Bowser
            	        bulletImage = bowserBulletGif.getImage();  // Imagen de la bala de Bowser
            	        bulletWidth = bullet.width;  // Tamaño de la bala de Bowser (por ejemplo, 10)
            	        bulletHeight = bullet.height; // Tamaño de la bala de Bowser (por ejemplo, 10)
            	    }

            	    // Dibujar la imagen de la bala con el tamaño correspondiente
            	    g.drawImage(bulletImage, (int) (bullet.x - mapOffsetX), (int) bullet.y, bulletWidth, bulletHeight, this);
            	}

            g.setColor(Color.RED);
            g.setFont(new Font("Arial", Font.BOLD, 20));
            String bowserHP = "Bowser HP: " + bowser.lives;
            g.drawString(bowserHP, 10, 30);
        }

        if (gameWon) {
            JFrame ventana = (JFrame) SwingUtilities.getWindowAncestor(this);
            ventana.dispose();
            You_Won.main(new String[]{});
        } else if (gameOver) {
            JFrame ventana = (JFrame) SwingUtilities.getWindowAncestor(this);
            ventana.dispose();
            Game_Over.main(new String[]{});
        }
    }
    
    private static final int BOMB_INTERVAL_LEVEL3 = 50; 
    private int bombaTimer = 0;
    private static final int BOMBS_PER_WAVE = 10; 

    @Override
    public void actionPerformed(ActionEvent e) {
        if (inMenu || gameWon || gameOver) return;

        if (inKnockback) {
            knockbackDuration--;
            if (knockbackDuration <= 0) {
                inKnockback = false;
            }
        }
        
        for (Rectangle obs : obstacles) {
            if (obs instanceof ZigzagObstacle) {
                ((ZigzagObstacle) obs).update();
            } else if (obs instanceof MovingObstacle) {
                ((MovingObstacle) obs).update();
            }
        }
        
        velocityY += GRAVITY;
        playerY += velocityY;

        if (playerY >= HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE) {
            playerY = HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE;
            velocityY = 0;
            jumping = false;
        }

        if (movingLeft) {
            playerSpeedX -= ACCELERATION_X;
        } else if (movingRight) {
            playerSpeedX += ACCELERATION_X;
        } else {
            if (playerSpeedX > 0) {
                playerSpeedX = Math.max(0, playerSpeedX - DECELERATION_X);
            } else if (playerSpeedX < 0) {
                playerSpeedX = Math.min(0, playerSpeedX + DECELERATION_X);
            }
        }

        playerSpeedX = Math.max(-MAX_SPEED_X, Math.min(MAX_SPEED_X, playerSpeedX));
        playerX += playerSpeedX;

        if (playerX < 0) {
            playerX = 0;
        } else if (playerX > MAP_WIDTH - PLAYER_SIZE) {
            playerX = MAP_WIDTH - PLAYER_SIZE;
        }

        List<BombaCayendo> bombasAEliminar = new ArrayList<>();
        for (BombaCayendo bomba : bombas) {
            bomba.actualizar();
            if (bomba.debeDesaparecer()) {
                bombasAEliminar.add(bomba);
            }
        }
        bombas.removeAll(bombasAEliminar);

        if (level == 3) {
            bombaTimer++;
            if (bombaTimer >= BOMB_INTERVAL_LEVEL3) {
                generateBombWave();
                bombaTimer = 0;
            }
        }

        if (level == 5) {
            updateLevel5();
        }

        checkCollisions();

        if (level != 5 && playerX + PLAYER_SIZE > goal.x && playerX < goal.x + GOAL_SIZE &&
            playerY + PLAYER_SIZE > goal.y && playerY < goal.y + GOAL_SIZE) {
            level++;
            if (level > 5) {
                level = 5;
                gameWon = true;
                timer.stop();
            } else {
                initializeLevel(level);
                playerX = 0;
                playerY = HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE;
            }
        }

        if (lives <= 0) {
            gameOver = true;
            timer.stop();
        }

        repaint();
    }
    
    private void generateBombWave() {
        for (int i = 0; i < BOMBS_PER_WAVE; i++) {
            bombas.add(new BombaCayendo(
                (int) (Math.random() * (MAP_WIDTH - 30)),
                -30 - (int)(Math.random() * 100),
                30,
                30,
                2f + (float)(Math.random() * 2)
            ));
        }
    }
    
    private void updateLevel5() {
        bowser.update();

        // Actualizar balas
        List<Bullet> bulletsToRemove = new ArrayList<>();
        for (Bullet bullet : bullets) {
            bullet.update();
            if (bullet.x < 0 || bullet.x > MAP_WIDTH) {
                bulletsToRemove.add(bullet);
            }
        }
        bullets.removeAll(bulletsToRemove);

        // Disparar balas de Bowser
        if (bowser.canShoot()) {
            bullets.add(new Bullet((int)bowser.x, (int)bowser.y + bowser.height / -50, 50, 50 , -10, false));
            bowser.resetShootTimer();
        }

        // Disparar balas del jugador
        if (shooting && shootCooldown == 0) {
            bullets.add(new Bullet((int)playerX + PLAYER_SIZE, (int)playerY + PLAYER_SIZE / 10, 40, 40, 10, true));
            shootCooldown = 25; // 0.5 segundos de cooldown
        }
        if (shootCooldown > 0) shootCooldown--;

       

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        // Colisiones de balas
        checkBulletCollisions();
    }

    private void checkBulletCollisions() {
        Rectangle playerRect = new Rectangle((int) playerX, (int) playerY, PLAYER_SIZE, PLAYER_SIZE);
        Rectangle bowserRect = new Rectangle((int) bowser.x, (int) bowser.y, bowser.width, bowser.height);

        List<Bullet> bulletsToRemove = new ArrayList<>();
        for (Bullet bullet : bullets) {
            if (bullet.isPlayerBullet) {
                if (bullet.intersects(bowserRect)) {
                    bowser.lives--;
                    bulletsToRemove.add(bullet);
                    if (bowser.lives <= 0) {
                        gameWon = true;
                        timer.stop();
                    }
                }
            } else {
                if (bullet.intersects(playerRect)) {
                    lives--;
                    bulletsToRemove.add(bullet);
                    if (lives <= 0) {
                        gameOver = true;
                        timer.stop();
                    }
                }
            }
        }
        bullets.removeAll(bulletsToRemove);
    }

    private void checkCollisions() {
        Rectangle playerRect = new Rectangle((int) playerX, (int) playerY, PLAYER_SIZE, PLAYER_SIZE);

        for (Rectangle obs : obstacles) {
            Rectangle obsRect = new Rectangle((int) obs.x, (int) obs.y, obs.width, obs.height);

            if (playerRect.intersects(obsRect)) {
                if (level == 2) {
                    playerX = 100;
                    playerY = HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE;
                    velocityY = 0;
                    playerSpeedX = 0;
                    lives--;

                    startKnockback();
                    break;
                }

                if (velocityY > 0 && playerY + PLAYER_SIZE > obs.y && playerY < obs.y + obs.height) {
                    playerY = obs.y - PLAYER_SIZE;
                    velocityY = -JUMP_STRENGTH * 1f;
                    playerSpeedX *= -10f;
                    lives--;
                } else if (velocityY < 0 && playerY < obs.y + obs.height && playerY + PLAYER_SIZE > obs.y) {
                    playerY = obs.y + obs.height;
                    velocityY = JUMP_STRENGTH * 10f;
                    playerSpeedX *= -10f;
                    lives--;
                } else if (playerSpeedX != 0) {
                    if (playerSpeedX > 0) {
                        playerX = obs.x - PLAYER_SIZE;
                        playerSpeedX = -MAX_SPEED_X * 10f;
                    } else {
                        playerX = obs.x + obs.width;
                        playerSpeedX = MAX_SPEED_X * 1.5f;
                    }
                    velocityY = -JUMP_STRENGTH * -1f;
                    lives--;
                }
                
                startKnockback();
                break;
            }
        }

        for (BombaCayendo bomba : bombas) {
            Rectangle bombaRect = new Rectangle((int) bomba.x, (int) bomba.y, bomba.width, bomba.height);

            if (playerRect.intersects(bombaRect)) {
                lives--;
                bomba.y = HEIGHT;
                bomba.velocidad = 0;
                startKnockback();
                break;
            }
        }
    }
    
    private void startKnockback() {
        inKnockback = true;
        knockbackDuration = MAX_KNOCKBACK_DURATION;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if (inMenu) {
            handleMenuKeyPress(keyCode);
        } else {
            handleGameKeyPress(keyCode);
        }
    }

    private void handleMenuKeyPress(int keyCode) {
        if (keyCode == KeyEvent.VK_UP) {
            menuSelection = (menuSelection == 0) ? 1 : 0;
            repaint();
        } else if (keyCode == KeyEvent.VK_DOWN) {
            menuSelection = (menuSelection == 1) ? 0 : 1;
            repaint();
        } else if (keyCode == KeyEvent.VK_ENTER) {
            if (menuSelection == 0) {
                inMenu = false;
                resetGame();
            } else if (menuSelection == 1) {
                System.exit(0);
            }
        }
    }

    private void handleGameKeyPress(int keyCode) {
        if (keyCode == KeyEvent.VK_LEFT) {
            movingLeft = true;
        } else if (keyCode == KeyEvent.VK_RIGHT) {
            movingRight = true;
        } else if (keyCode == KeyEvent.VK_UP && !jumping && playerY == HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE) {
            jumping = true;
            velocityY = -JUMP_STRENGTH;
        } else if (keyCode == KeyEvent.VK_R && (gameOver || gameWon)) {
            resetGame();
        } else if (keyCode == KeyEvent.VK_SPACE && level == 5) {
            shooting = true;
        }
    }

    private void resetGame() {
        level = 1;
        lives = 3;
        gameWon = false;
        gameOver = false;
        initializeLevel(level);
        playerX = 0;
        playerY = HEIGHT - FLOOR_HEIGHT - PLAYER_SIZE;
        playerSpeedX = 0;
        velocityY = 0;
        jumping = false;
        inKnockback = false;
        knockbackDuration = 0;
        timer.start();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int keyCode = e.getKeyCode();
        if (keyCode == KeyEvent.VK_LEFT) {
            movingLeft = false;
        } else if (keyCode == KeyEvent.VK_RIGHT) {
            movingRight = false;
        } else if (keyCode == KeyEvent.VK_SPACE) {
            shooting = false;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // No se necesita implementar para este juego
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Juego de Aventuras");
            JuegoAventuras game = new JuegoAventuras();
            frame.add(game);
            frame.pack();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}